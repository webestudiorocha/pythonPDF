import pdfkit
path_wkthmltopdf = r'C:\Users\Acer Aspire 3\AppData\Local\Programs\Python\Python37-32\wkhtmltopdf\bin\wkhtmltopdf.exe'
config = pdfkit.configuration(wkhtmltopdf=path_wkthmltopdf)
options = {
    'page-size': 'A4',
    'margin-top': '0.75in',
    'margin-right': '0.75in',
    'margin-bottom': '0.75in',
    'margin-left': '0.75in',
}
pdfkit.from_url("http://192.168.0.55/aimar/repuestos/PDF/nuevoPDF", "listo.pdf", configuration=config)
